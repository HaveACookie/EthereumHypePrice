<h1>Using the Analytics code</h1>


<p>There are multiple analytics programs with corresponding files. Data ProfilerAndMerger Creates the Files for each one(This can be found on lines 48-51 of DataProfilerAndMerger.scala). Merged and out3 correspond with DataProfilerandMerger, which generates a file for pearson_correlation. Merged2 corresponds with analytics.
construction_the_merged_data_for_pearson_correlation generates a file called merged4 which is used in pearson_correlation
</p>